from django.apps import AppConfig


class LoggerConfig(AppConfig):
    name = 'logger'
