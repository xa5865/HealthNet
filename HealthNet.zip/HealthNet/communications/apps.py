from django.apps import AppConfig


class CommunicationsConfig(AppConfig):
    name = 'communications'
